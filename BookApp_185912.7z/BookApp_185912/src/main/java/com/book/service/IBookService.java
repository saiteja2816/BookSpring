package com.book.service;

import java.util.List;

import com.book.bean.Book;
import com.book.exception.IDException;
import com.book.exception.NotFoundException;


public interface IBookService {
	boolean addBook(Book book) throws IDException;
	 public List<Book> findByAuthor(String author);
	 public Book findByBookID(int id)throws NotFoundException;
	List<Book> getAllBooks();
	

}
