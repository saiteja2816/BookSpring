package com.book.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.bean.Book;
import com.book.dao.BookDao;
import com.book.exception.IDException;
import com.book.exception.NotFoundException;
import com.book.bean.Book;
import com.book.exception.NotFoundException;



@Service
public class BookServiceImpl implements IBookService{
	@Autowired
	BookDao bookdao;

	@Override
	public boolean addBook(Book book) throws IDException {
		try {
            if(bookdao.save(book) != null);
            return    true;
        }
        catch(Exception ex)
        {
            throw new IDException("Id already exists");
        }
	
		
	}


	@Override
	public Book findByBookID(int id) throws NotFoundException {
		try
		{
		return bookdao.findById(id).get();
		}
		catch(Exception e) {
		throw new NotFoundException("Book with Id"+id+" does not exist");
	}
	}
	


	@Override
	public List<Book> findByAuthor(String author) {
	
		return bookdao.findByAuthor(author);
	}


	public List<Book> getAllBooks() {
		
			return bookdao.findAll();
		
		
	
	}
}
